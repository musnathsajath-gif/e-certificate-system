<?php
require_once __DIR__ . '/includes/bootstrap.php';
$error = ''; $tracking = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tracking = trim((string)($_POST['tracking_number'] ?? ''));
    if ($tracking === '') {
        $error = 'Please enter your Tracking Number.';
    } else {
        header('Location: verify.php?id=' . rawurlencode($tracking)); exit;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Certificate Verification | Next Level Academy</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,700;0,800;1,600&display=swap" rel="stylesheet">
<style>
  *{font-family:'Inter',sans-serif}
  body{ background:#FFFEFA; color:#1A1A1A; min-height:100vh; display:flex; flex-direction:column; }
  .topbar{ background:linear-gradient(90deg,#0A2540,#123A63,#0A2540); color:#FFE9A8; font-size:12px; letter-spacing:2px; text-transform:uppercase; padding:10px 0; text-align:center; font-weight:600; }
  .topbar b{ color:#fff; }
  .navbar-elegant{ background:#fff; border-bottom:2px solid #F5E6B8; padding:14px 0; position:sticky; top:0; z-index:20; box-shadow:0 4px 20px rgba(0,0,0,.06); }
  .brand{ display:flex; align-items:center; gap:14px; text-decoration:none; }
  .brand-logo{ height:56px; width:auto; max-width:230px; object-fit:contain; display:block; }
  .brand-text{ line-height:1.15; }
  .brand-text .brand-main{ font-family:'Playfair Display',serif; font-size:26px; color:#0A2540; display:block; font-weight:800; letter-spacing:-.3px; }
  .brand-text .brand-sub{ font-size:10px; letter-spacing:3px; color:#C9A227; font-weight:800; text-transform:uppercase; }
  .login-link{ background:#0A2540; color:#fff; padding:11px 22px; border-radius:100px; font-size:13px; font-weight:700; text-decoration:none; box-shadow:0 8px 20px rgba(10,37,64,.25); }
  .login-link:hover{ background:#C9A227; color:#fff; }
  .main{ flex:1; padding:55px 15px 60px; background:radial-gradient(ellipse at top, #FFF9E6 0%, #FFFEFA 55%); display:flex; align-items:center; }
  .eyebrow{ display:flex; align-items:center; justify-content:center; gap:12px; color:#B8962E; font-size:11px; letter-spacing:3.5px; font-weight:800; }
  .eyebrow::before,.eyebrow::after{ content:""; width:42px; height:2px; background:linear-gradient(90deg,transparent,#C9A227); }
  .eyebrow::after{ background:linear-gradient(90deg,#C9A227,transparent); }
  .hero-title{ font-family:'Playfair Display',serif; font-size:clamp(40px,6vw,62px); color:#0A2540; text-align:center; margin:16px 0 10px; line-height:1; font-weight:800; }
  .hero-title em{ background:linear-gradient(90deg,#C9A227,#F5D67B,#C9A227); -webkit-background-clip:text; -webkit-text-fill-color:transparent; font-weight:700; }
  .hero-desc{ text-align:center; color:#666; max-width:640px; margin:0 auto; font-size:15.5px; line-height:1.8; }
  .trust{ display:flex; justify-content:center; gap:12px; margin:26px 0 34px; flex-wrap:wrap; }
  .trust span{ background:#fff; border:1px solid #F5E6B8; padding:9px 16px; border-radius:100px; font-size:12.5px; font-weight:600; color:#333; box-shadow:0 4px 12px rgba(201,162,39,.12); }
  .card-elegant{ max-width:600px; margin:0 auto; background:#fff; border:1px solid #F5E6B8; border-radius:22px; box-shadow:0 25px 60px rgba(10,37,64,.12); overflow:hidden; }
  .card-top{ padding:32px 32px 0; text-align:center; }
  .card-top h2{ font-family:'Playfair Display',serif; font-size:32px; color:#0A2540; margin:0; }
  .card-top p{ color:#999; font-size:13.5px; margin:6px 0 0; }
  .gold-line{ width:60px; height:3px; background:linear-gradient(90deg,#C9A227,#F5D67B); margin:16px auto 0; border-radius:10px; }
  .card-body-custom{ padding:28px 32px 32px; }
  .form-label{ font-size:12px; letter-spacing:.6px; text-transform:uppercase; font-weight:800; color:#222; margin-bottom:10px; }
  .form-control{ height:60px; border:2px solid #F0E6C5; border-radius:14px; font-size:16px; padding:0 16px; background:#FFFEFA; font-weight:700; letter-spacing:1px; text-transform:uppercase; text-align:center; }
  .form-control:focus{ border-color:#C9A227; box-shadow:0 0 0 4px rgba(201,162,39,.18); background:#fff; }
  .note{ background:#FFF9E6; border:1px solid #F5E6B8; border-radius:12px; padding:14px 16px; font-size:12.5px; line-height:1.7; color:#6B5A35; text-align:center; }
  .btn-elegant{ width:100%; height:58px; background:linear-gradient(90deg,#0A2540,#123A63); color:#fff; border:none; border-radius:100px; font-size:14px; letter-spacing:1.2px; font-weight:800; text-transform:uppercase; box-shadow:0 12px 25px rgba(10,37,64,.25); transition:.3s; }
  .btn-elegant:hover{ background:linear-gradient(90deg,#C9A227,#E5C76B); color:#0A2540; transform:translateY(-2px); }
  .footer-elegant{ background:#0A2540; color:#8A9AAE; text-align:center; padding:24px 15px; font-size:12px; }
  .footer-elegant b{ color:#FFE9A8; }
  @media(max-width:576px){ .brand-text .brand-main{ font-size:19px; } .brand-logo{ height:42px; max-width:150px; } }
</style>
</head>
<body>
<div class="topbar">✦ &nbsp; <b>OFFICIAL & SECURE</b> &nbsp; • &nbsp; NEXT LEVEL ACADEMY &nbsp; • &nbsp; 100% VERIFIED</div>
<nav class="navbar-elegant">
  <div class="container d-flex justify-content-between align-items-center">
    <a href="index.php" class="brand">
      <img src="images/dddf.jpg?v=3" alt="Next Level Academy" class="brand-logo">
      <span class="brand-text"><span class="brand-main">Certificate Verification</span><span class="brand-sub">Next Level Academy • Official Portal</span></span>
    </a>
    <a href="admin/login.php" class="login-link">Institution Login →</a>
  </div>
</nav>
<main class="main"><div class="container">
  <div class="eyebrow">Official Credential Portal</div>
  <h1 class="hero-title">Certificate <em>Verification</em></h1>
  <p class="hero-desc">Enter your Tracking Number to verify your certificate instantly.</p>
  <div class="trust"><span>✓ Instant Verification</span><span>✓ Tamper-Proof Records</span><span>✓ Trusted by Institutions</span></div>
  <?php if ($error): ?><div class="alert alert-danger text-center" style="max-width:600px;margin:0 auto 20px;border-radius:12px;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <section class="card-elegant">
    <div class="card-top"><h2>Search Certificate Details</h2><p>Enter your Tracking Number below.</p><div class="gold-line"></div></div>
    <div class="card-body-custom">
      <form method="post" action="index.php">
        <div class="mb-4">
          <label class="form-label">🎯 Tracking Number *</label>
          <input type="text" name="tracking_number" class="form-control" placeholder="Ex: NLA-2026-00123" required autofocus value="<?= htmlspecialchars($tracking) ?>">
        </div>
        <div class="note mb-4">Your Tracking Number is printed on your certificate. Enter it above to view your certificate details on the next page.</div>
        <button type="submit" class="btn-elegant">Search &amp; Verify Certificate →</button>
      </form>
    </div>
  </section>
</div></main>
<footer class="footer-elegant">© <?= date('Y') ?> <b>Next Level Academy</b> &nbsp;•&nbsp; CERTIFICATE VERIFICATION PORTAL &nbsp;•&nbsp; ALL RIGHTS RESERVED</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>