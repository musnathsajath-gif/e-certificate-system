
<?php

// Start secure session
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (
        !empty($_SERVER['HTTPS']) &&
        $_SERVER['HTTPS'] !== 'off'
    );

    session_set_cookie_params([
        'httponly' => true,
        'secure' => $secure,
        'samesite' => 'Lax',
        'path' => '/',
    ]);

    session_start();
}

// Database connection
require_once __DIR__ . '/../config/database.php';

// Escape HTML output
function h(?string $value): string {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

// CSRF token
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

// Verify CSRF token
function csrf_check(): void {
    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals(
            $_SESSION['csrf_token'] ?? '',
            $token
        )
    ) {
        http_response_code(403);
        exit('Invalid request token. Please refresh and try again.');
    }
}

// Require admin login
function require_admin(): void {
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }
}

// Application base URL
function app_base_url(): string {
    $https = (
        !empty($_SERVER['HTTPS']) &&
        $_SERVER['HTTPS'] !== 'off'
    );

    $scheme = $https ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';

    $script = str_replace(
        '\\',
        '/',
        dirname($_SERVER['SCRIPT_NAME'] ?? '/')
    );

    $script = rtrim($script, '/');

    if ($script === '.' || $script === '/') {
        $script = '';
    }

    $script = preg_replace('#/admin$#', '', $script);

    return $scheme . '://' . $host . $script;
}

// Get settings for the logged-in admin
function get_settings(PDO $pdo): array {

    if (empty($_SESSION['admin_id'])) {
        return [
            'institution_name' => 'Next_Level_Acadamy',
            'certificate_prefix' => 'NS',
            'numbering_year' => (int)date('Y'),
            'footer_text' => ''
        ];
    }

    $adminId = (int) $_SESSION['admin_id'];

    $stmt = $pdo->prepare(
        'SELECT * FROM settings
         WHERE owner_admin_id = ?
         LIMIT 1'
    );

    $stmt->execute([$adminId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        return $row;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO settings
        (
            owner_admin_id,
            institution_name,
            certificate_prefix,
            numbering_year,
            footer_text
        )
        VALUES (?, ?, ?, ?, ?)'
    );

    $stmt->execute([
        $adminId,
        'My Institution',
        'NS',
        (int)date('Y'),
        ''
    ]);

    $stmt = $pdo->prepare(
        'SELECT * FROM settings
         WHERE owner_admin_id = ?
         LIMIT 1'
    );

    $stmt->execute([$adminId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        throw new RuntimeException('Unable to load admin settings.');
    }

    return $row;
}
