<?php
require_once __DIR__ . '/bootstrap.php';
require_admin();
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($page_title ?? 'Admin') ?> · Certificate Portal</title>
<link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<nav class="topbar">
  <a class="brand" href="dashboard.php">Certificate Admin</a>
  <div class="navlinks">
    <a href="dashboard.php">Dashboard</a>
    <a href="add-certificate.php">Add Certificate</a>
    <a href="certificates.php">Manage</a>
    <a href="settings.php">Settings</a>
    <a href="logout.php">Logout</a>
  </div>
</nav>
<main class="container">
