</main>
<footer class="footer">Certificate Verification System</footer>
</body>
</html>
