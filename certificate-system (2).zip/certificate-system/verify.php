<?php
include 'config.php';
$tracking = trim($_GET['id'] ?? $_GET['tracking'] ?? '');
$cert = null;
if($tracking){
    $stmt=$conn->prepare("SELECT * FROM certificates WHERE tracking_number=?");
    $stmt->bind_param("s",$tracking); $stmt->execute(); $cert=$stmt->get_result()->fetch_assoc();
}
$currentLink = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
?>
<!DOCTYPE html><html><head><title>Verify Certificate</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body{background:#FFF8E1;font-family:'Poppins',sans-serif}
.cert-wrap{position:relative;width:100%;max-width:850px;margin:auto;border-radius:16px;overflow:hidden;border:3px solid #D4AF37;background:#fff}
.cert-wrap img{width:100%;display:block}
.name-overlay{position:absolute;left:0;right:0;top:51%;text-align:center}
.student-name{font-family:'Playfair Display',serif;font-size:38px;font-weight:700;text-transform:capitalize}
.course-line{font-size:14px;color:#555;margin-top:10px;font-weight:600}
@media print{ .no-print{display:none!important} body{background:#fff} }
</style></head><body>
<div class="container py-4 text-center no-print"><h2 class="fw-bold">NEXT LEVEL ACADEMY</h2><p class="text-muted">Certificate Verification - Official Portal</p></div>
<div class="container py-2">
<?php if($cert): ?>
<div class="text-center mb-3 no-print"><span class="badge bg-success p-3 fs-6">✓ VERIFIED - Original Certificate</span></div>
<div class="cert-wrap" id="certBox">
<?php $img=$cert['certificate_image']?:'444.jpg'; if(!file_exists("images/".$img)) $img='444.jpg'; ?>
<img src="images/<?= htmlspecialchars($img) ?>">
<div class="name-overlay"><div class="student-name"><?= htmlspecialchars($cert['student_name']) ?></div>
<div class="course-line"><?= htmlspecialchars($cert['course_name']) ?> • <?= htmlspecialchars($cert['institution']) ?></div>
<div class="track-line small text-muted">Issued: <?= date('d-m-Y', strtotime($cert['issue_date'])) ?> | Tracking: <?= htmlspecialchars($cert['tracking_number']) ?></div></div>
</div>

<!-- STUDENT ACTIONS -->
<div class="card mt-4 p-4 text-center shadow no-print" style="max-width:850px;margin:auto;border-radius:16px">
<h4 class="fw-bold">🎓 <?= htmlspecialchars($cert['student_name']) ?> - Certificate Ready!</h4>
<p class="text-muted">Itha Print pannalam, Download pannalam, Link-a Share pannalam!</p>
<div class="d-flex flex-wrap gap-2 justify-content-center">
<button onclick="window.print()" class="btn btn-warning fw-bold px-4">🖨️ Print Certificate</button>
<a href="images/<?= htmlspecialchars($img) ?>" download="Certificate-<?= htmlspecialchars($cert['tracking_number']) ?>.jpg" class="btn btn-primary fw-bold px-4">⬇️ Download Certificate</a>
<button onclick="navigator.clipboard.writeText('<?= $currentLink ?>');alert('Link Copied!')" class="btn btn-dark fw-bold px-4">🔗 Copy Link</button>
<a href="https://wa.me/?text=<?= urlencode('My Certificate: '.$currentLink) ?>" target="_blank" class="btn btn-success fw-bold px-4">📱 WhatsApp Share</a>
</div>
<div class="mt-3"><label class="small fw-bold">Your Certificate Link:</label><input type="text" class="form-control text-center" value="<?= $currentLink ?>" readonly onclick="this.select()"></div>
<table class="table table-bordered mt-3 text-start"><tr><th>Student</th><td><?= htmlspecialchars($cert['student_name']) ?></td></tr><tr><th>Course</th><td><?= htmlspecialchars($cert['course_name']) ?></td></tr><tr><th>Tracking</th><td><b><?= htmlspecialchars($cert['tracking_number']) ?></b></td></tr><tr><th>Status</th><td><span class="badge bg-success">Verified ✅</span></td></tr></table>
</div>
<?php else: ?>
<div class="alert alert-danger text-center p-4" style="max-width:650px;margin:auto;border-radius:16px"><h4>Certificate Not Found</h4><p>No certificate found for: <b><?= htmlspecialchars($tracking) ?></b></p><a href="index.php" class="btn btn-dark">Try Again →</a></div>
<?php endif; ?>
</div></body></html>