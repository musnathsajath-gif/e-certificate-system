<?php
session_start();
if(!isset($_SESSION['admin'])){ header("Location: login.php"); exit; }
include '../config.php';

$message=""; $link="";

if($_SERVER['REQUEST_METHOD']=='POST'){
    $student = $_POST['student_name'];
    $inst    = $_POST['institution'];
    $course  = $_POST['course_name'];
    $date    = $_POST['issue_date'];

    // Tracking Number - Auto Generate
    $tracking = "NLA-".date('Y')."-".str_pad(rand(1,99999),5,'0',STR_PAD_LEFT);

    // Default Image - Upload pannalana ithu varum
    $imageName = "444.jpg";

    // ===== ADMIN UPLOAD - ITHU THAAN MAIN PHP =====
    if(!empty($_FILES['certificate_image']['name'])){
        $uploadDir = "../images/";
        if(!is_dir($uploadDir)){ mkdir($uploadDir, 0777, true); }

        $fileTmp  = $_FILES['certificate_image']['tmp_name'];
        $fileName = basename($_FILES['certificate_image']['name']);
        $fileExt  = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed  = ['jpg','jpeg','png','webp'];

        if(in_array($fileExt, $allowed)){
            $imageName = time()."_".$fileName;
            move_uploaded_file($fileTmp, $uploadDir.$imageName);
        } else {
            $message = "❌ JPG / PNG mattum upload pannunga!";
        }
    }

    if(empty($message) || str_starts_with($message, "✅") || $message==""){
        $stmt = $conn->prepare("INSERT INTO certificates (student_name,institution,course_name,issue_date,tracking_number,certificate_image) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("ssssss", $student, $inst, $course, $date, $tracking, $imageName);
        if($stmt->execute()){
            $link = "http://localhost/certificate-system/verify.php?id=".$tracking;
            $message = "✅ Certificate Saved! Tracking: ".$tracking;
        } else {
            $message = "❌ Error: ".$conn->error;
        }
    }
}
?>
<!DOCTYPE html><html><head><title>Add Certificate - Next Level Academy</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Poppins',sans-serif} body{background:#F1F3F6}
.topbar{background:#0A1931;padding:12px 0;border-bottom:3px solid #C9A227}
.topbar img{height:44px;background:#fff;padding:5px 12px;border-radius:8px}
.main-card{background:#fff;border-radius:18px;box-shadow:0 15px 40px rgba(10,25,49,.08);border-top:4px solid #C9A227}
.form-control{border-radius:10px;padding:11px 14px;border:1.5px solid #E2E8F0;background:#F8FAFC}
label{font-size:12px;font-weight:600;color:#0A1931}
.upload-box{border:2px dashed #1E5AA8;border-radius:14px;padding:22px;text-align:center;background:#F0F6FF;cursor:pointer}
.upload-box:hover{border-color:#C9A227;background:#FFFBEA}
.upload-box input{display:none}
.preview-img{max-width:100%;border-radius:12px;border:2px solid #C9A227;display:none;margin-top:12px}
.btn-save{background:#1E5AA8;color:#fff;font-weight:700;border:none;border-radius:12px;padding:13px;width:100%;transition:.25s}
.btn-save:hover{background:#C9A227;color:#fff}
.btn-blue-sm{background:#1E5AA8;color:#fff;font-weight:600;border:none;border-radius:8px;padding:6px 14px;font-size:13px}
.btn-blue-sm:hover{background:#C9A227;color:#fff}
</style></head>
<body>
<div class="topbar"><div class="container d-flex justify-content-between align-items-center">
<img src="../images/logo.png" onerror="this.src='../images/logo.jpg';this.onerror=null;this.src='../images/dddf.jpg'">
<span class="text-white fw-bold small">ADMIN PANEL • NEXT LEVEL ACADEMY</span>
</div></div>

<div class="container py-4"><div class="row justify-content-center"><div class="col-md-7">
<div class="main-card p-4 p-md-5">
<h4 class="fw-bold text-center" style="color:#0A1931">➕ Add New Certificate</h4>
<p class="text-center text-muted small mb-4">Student details + Certificate Upload</p>

<?php if($message): ?>
<div class="alert alert-success rounded-3"><b><?= $message ?></b><br><br>
<?php if($link): ?><b>Student Link:</b>
<input type="text" id="linkBox" class="form-control mb-2" value="<?= $link ?>" readonly>
<button onclick="navigator.clipboard.writeText(document.getElementById('linkBox').value);alert('Link Copied!')" class="btn-blue-sm">📋 Copy</button>
<a href="<?= $link ?>" target="_blank" class="btn-blue-sm text-decoration-none">👁️ View</a>
<?php endif; ?>
</div><?php endif; ?>

<!-- IMPORTANT: enctype="multipart/form-data" - Illana Upload aagathu! -->
<form method="POST" enctype="multipart/form-data">
<label class="mb-1">STUDENT NAME *</label>
<input type="text" name="student_name" class="form-control mb-3" placeholder="Ex: Ahmed" required>

<label class="mb-1">INSTITUTION</label>
<input type="text" name="institution" class="form-control mb-3" value="Next Level Academy" required>

<label class="mb-1">COURSE NAME *</label>
<input type="text" name="course_name" class="form-control mb-3" placeholder="Ex: Computer Course" required>

<label class="mb-1">ISSUE DATE</label>
<input type="date" name="issue_date" class="form-control mb-3" required>

<label class="mb-1">📤 UPLOAD CERTIFICATE IMAGE</label>
<div class="upload-box" onclick="document.getElementById('certFile').click()">
<div style="font-size:36px">📤</div>
<b style="color:#1E5AA8">Click to Upload Certificate Image</b><br>
<small class="text-muted">JPG / PNG / JPEG - Upload pannalana 444.jpg varum</small>
<input type="file" id="certFile" name="certificate_image" accept="image/*" onchange="previewImage(this)">
<img id="preview" class="preview-img">
</div>

<button class="btn-save mt-3">SAVE & GENERATE LINK →</button>
</form>
<p class="text-center mt-3 small"><a href="dashboard.php" style="color:#1E5AA8;font-weight:600;text-decoration:none">← Back to Dashboard</a></p>
</div></div></div></div>

<script>
function previewImage(input){
  if(input.files && input.files[0]){
    var r=new FileReader();
    r.onload=function(e){ var p=document.getElementById('preview'); p.src=e.target.result; p.style.display='block'; }
    r.readAsDataURL(input.files[0]);
  }
}
</script>
</body></html>