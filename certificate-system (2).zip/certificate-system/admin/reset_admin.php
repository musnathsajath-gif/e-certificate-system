
<?php
declare(strict_types=1);

// Security: Disable the old public password reset installer.
http_response_code(403);
header('Content-Type: text/plain; charset=UTF-8');

exit('Access denied. This password reset script has been disabled.');
