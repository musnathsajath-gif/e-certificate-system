
<?php
$page_title = 'Edit Certificate';
require_once __DIR__ . '/../includes/admin_header.php';

$adminId = (int) $_SESSION['admin_id'];
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;

$stmt = $pdo->prepare(
    'SELECT *
     FROM certificates
     WHERE id = ? AND owner_admin_id = ?
     LIMIT 1'
);
$stmt->execute([$id, $adminId]);
$cert = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$cert) {
    echo '<div class="alert error">Certificate not found.</div>';
    require __DIR__ . '/../includes/admin_footer.php';
    exit;
}

$errors = [];
$message = '';
$newImageAbsolute = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $student = trim((string)($_POST['student_name'] ?? ''));
    $course = trim((string)($_POST['course_name'] ?? ''));
    $duration = trim((string)($_POST['course_duration'] ?? ''));
    $completion = trim((string)($_POST['completion_date'] ?? '')) ?: null;
    $issue = trim((string)($_POST['issue_date'] ?? ''));
    $institution = trim((string)($_POST['institution_name'] ?? ''));
    $signatory = trim((string)($_POST['authorized_signatory'] ?? ''));
    $status = (string)($_POST['status'] ?? 'Valid');

    if ($student === '' || $course === '' || $issue === '') {
        $errors[] = 'Student, course, and issue date are required.';
    }

    if (!in_array($status, ['Valid', 'Revoked'], true)) {
        $errors[] = 'Invalid status.';
    }

    if ($issue !== '') {
        $date = DateTime::createFromFormat('!Y-m-d', $issue);
        if (!$date || $date->format('Y-m-d') !== $issue) {
            $errors[] = 'Please enter a valid issue date.';
        }
    }

    if ($completion !== null) {
        $date = DateTime::createFromFormat('!Y-m-d', $completion);
        if (!$date || $date->format('Y-m-d') !== $completion) {
            $errors[] = 'Please enter a valid completion date.';
        }
    }

    $newImage = $cert['certificate_image'];

    if (!$errors && isset($_FILES['certificate_image'])) {
        $uploadError = $_FILES['certificate_image']['error'];

        if ($uploadError !== UPLOAD_ERR_NO_FILE) {
            if ($uploadError !== UPLOAD_ERR_OK) {
                $errors[] = 'Image upload failed. Please try again.';
            } else {
                $file = $_FILES['certificate_image'];

                if ($file['size'] > 5 * 1024 * 1024) {
                    $errors[] = 'Image must be 5 MB or smaller.';
                }

                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($file['tmp_name']);

                $allowed = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp'
                ];

                if (
                    !isset($allowed[$mime]) ||
                    @getimagesize($file['tmp_name']) === false
                ) {
                    $errors[] = 'Only valid JPG, PNG, or WebP images are allowed.';
                }

                if (!$errors) {
                    $dir = dirname(__DIR__) . '/uploads/certificates/';

                    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
                        $errors[] = 'Could not create upload directory.';
                    }

                    if (!$errors) {
                        $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
                        $newImageAbsolute = $dir . $filename;

                        if (move_uploaded_file($file['tmp_name'], $newImageAbsolute)) {
                            $newImage = '../uploads/certificates/' . $filename;
                        } else {
                            $errors[] = 'Image upload failed.';
                            $newImageAbsolute = '';
                        }
                    }
                }
            }
        }
    }

    if (!$errors) {
        try {
            $upd = $pdo->prepare(
                'UPDATE certificates
                 SET student_name = ?,
                     course_name = ?,
                     course_duration = ?,
                     completion_date = ?,
                     issue_date = ?,
                     certificate_image = ?,
                     institution_name = ?,
                     authorized_signatory = ?,
                     status = ?
                 WHERE id = ? AND owner_admin_id = ?'
            );

            $upd->execute([
                $student,
                $course,
                $duration ?: null,
                $completion,
                $issue,
                $newImage,
                $institution ?: null,
                $signatory ?: null,
                $status,
                $id,
                $adminId
            ]);

            if ($upd->rowCount() === 0) {
                // Check whether the record still belongs to this admin.
                $check = $pdo->prepare(
                    'SELECT id FROM certificates
                     WHERE id = ? AND owner_admin_id = ?
                     LIMIT 1'
                );
                $check->execute([$id, $adminId]);

                if (!$check->fetchColumn()) {
                    throw new RuntimeException('Certificate ownership check failed.');
                }
            }

            $message = 'Certificate updated.';

            // Reload only this admin's certificate.
            $stmt = $pdo->prepare(
                'SELECT *
                 FROM certificates
                 WHERE id = ? AND owner_admin_id = ?
                 LIMIT 1'
            );
            $stmt->execute([$id, $adminId]);
            $cert = $stmt->fetch(PDO::FETCH_ASSOC);

            $newImageAbsolute = '';

        } catch (Throwable $e) {
            if ($newImageAbsolute && is_file($newImageAbsolute)) {
                @unlink($newImageAbsolute);
            }

            error_log('Certificate update failed: ' . $e->getMessage());
            $errors[] = 'Could not update certificate. Please try again.';
        }
    }

    // Keep the newly entered values visible if validation fails.
    if ($errors) {
        $cert['student_name'] = $student;
        $cert['course_name'] = $course;
        $cert['course_duration'] = $duration;
        $cert['completion_date'] = $completion;
        $cert['issue_date'] = $issue;
        $cert['institution_name'] = $institution;
        $cert['authorized_signatory'] = $signatory;
        $cert['status'] = $status;
    }
}
?>

<div class="pagehead">
    <div>
        <div class="eyebrow"><?= h($cert['tracking_number']) ?></div>
        <h1>Edit Certificate</h1>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert success"><?= h($message) ?></div>
<?php endif; ?>

<?php foreach ($errors as $e): ?>
    <div class="alert error"><?= h($e) ?></div>
<?php endforeach; ?>

<section class="panel">
    <form method="post" enctype="multipart/form-data">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h(csrf_token()) ?>"
        >

        <div class="form-grid">

            <div>
                <label>Student name *</label>
                <input
                    name="student_name"
                    required
                    value="<?= h($cert['student_name']) ?>"
                >
            </div>

            <div>
                <label>Course name *</label>
                <input
                    name="course_name"
                    required
                    value="<?= h($cert['course_name']) ?>"
                >
            </div>

            <div>
                <label>Course duration</label>
                <input
                    name="course_duration"
                    value="<?= h($cert['course_duration']) ?>"
                >
            </div>

            <div>
                <label>Completion date</label>
                <input
                    type="date"
                    name="completion_date"
                    value="<?= h($cert['completion_date'] ?? '') ?>"
                >
            </div>

            <div>
                <label>Issue date *</label>
                <input
                    type="date"
                    name="issue_date"
                    required
                    value="<?= h($cert['issue_date']) ?>"
                >
            </div>

            <div>
                <label>Status</label>
                <select name="status">
                    <option value="Valid" <?= $cert['status'] === 'Valid' ? 'selected' : '' ?>>Valid</option>
                    <option value="Revoked" <?= $cert['status'] === 'Revoked' ? 'selected' : '' ?>>Revoked</option>
                </select>
            </div>

            <div>
                <label>Institution name</label>
                <input
                    name="institution_name"
                    value="<?= h($cert['institution_name'] ?? '') ?>"
                >
            </div>

            <div>
                <label>Authorized signatory</label>
                <input
                    name="authorized_signatory"
                    value="<?= h($cert['authorized_signatory'] ?? '') ?>"
                >
            </div>

            <div class="full">
                <label>Replace certificate image (optional)</label>
                <input
                    type="file"
                    name="certificate_image"
                    accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                >
            </div>

        </div>

        <p>
            <img
                class="thumb"
                src="<?= h($cert['certificate_image']) ?>"
                alt="Current certificate image"
            >
        </p>

        <div class="form-actions">
            <button type="submit">Save Changes</button>
            <a class="button secondary" href="certificates.php">Back</a>
        </div>

    </form>
</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
