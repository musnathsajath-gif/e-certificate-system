<?php
session_start();
if(!isset($_SESSION['admin'])){ header("Location: login.php"); exit; }
include '../config.php';
$all=$conn->query("SELECT * FROM certificates ORDER BY id DESC");
?>
<!DOCTYPE html><html><head><title>Admin Dashboard - Next Level Academy</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Poppins',sans-serif} body{background:#F1F3F6}
.topbar{background:#0A1931;padding:12px 0;border-bottom:3px solid #C9A227}
.topbar img{height:44px;background:#fff;padding:5px 12px;border-radius:8px}
.main-card{background:#fff;border-radius:16px;box-shadow:0 12px 30px rgba(10,25,49,.08);border-top:4px solid #C9A227}
/* BLUE BUTTON -> GOLD */
.btn-blue{background:#1E5AA8;color:#fff;font-weight:600;border:none;border-radius:10px;padding:8px 16px;transition:.25s}
.btn-blue:hover{background:#C9A227;color:#fff;transform:translateY(-1px)}
.btn-blue:active{background:#C9A227!important}
.btn-dark2{background:#0A1931;color:#fff;font-weight:600;border:none;border-radius:10px;padding:8px 16px;transition:.25s}
.btn-dark2:hover{background:#C9A227;color:#fff}
.table thead th{background:#0A1931;color:#fff;font-size:13px;border:none;padding:12px}
.table tbody td{vertical-align:middle;font-size:13.5px;padding:12px}
code{background:#EEF2FF;color:#1E5AA8;padding:4px 8px;border-radius:6px;font-weight:600}
.link-input{border:1.5px solid #E2E8F0;background:#F8FAFC;border-radius:8px;font-size:12px;padding:7px}
</style></head>
<body>
<div class="topbar"><div class="container d-flex justify-content-between align-items-center">
<img src="../images/logo.png" onerror="this.src='../images/logo.jpg';this.onerror=null;this.src='../images/dddf.jpg'" alt="NEXT LEVEL">
<span class="text-white fw-bold small">ADMIN PANEL • NEXT LEVEL ACADEMY</span>
</div></div>

<div class="container py-4">
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
<div><h4 class="fw-bold mb-0" style="color:#0A1931">Dashboard</h4><p class="text-muted small mb-0">Welcome back, Admin • Total: <?= $all->num_rows ?> Certificates</p></div>
<div class="d-flex gap-2">
<a href="add_certificate.php" class="btn-blue text-decoration-none">➕ Add Certificate</a>
<a href="logout.php" class="btn-dark2 text-decoration-none">Logout</a>
</div></div>

<div class="main-card p-4">
<h5 class="fw-bold mb-3">📋 All Certificates (<?= $all->num_rows ?>)</h5>
<div class="table-responsive">
<table class="table table-hover align-middle">
<thead><tr><th>#</th><th>Student</th><th>Course</th><th>Tracking</th><th style="min-width:280px">Certificate Link</th><th>Action</th></tr></thead>
<tbody>
<?php $i=1; while($r=$all->fetch_assoc()): $link="http://localhost/certificate-system/verify.php?id=".$r['tracking_number']; ?>
<tr>
<td><b><?= $i++ ?></b></td>
<td><b style="color:#0A1931"><?= htmlspecialchars($r['student_name']) ?></b><br><small class="text-muted"><?= htmlspecialchars($r['issue_date']) ?></small></td>
<td><?= htmlspecialchars($r['course_name']) ?><br><small class="text-muted"><?= htmlspecialchars($r['institution']) ?></small></td>
<td><code><?= $r['tracking_number'] ?></code></td>
<td>
<input type="text" id="l<?= $r['id'] ?>" class="form-control link-input mb-2" value="<?= $link ?>" readonly>
<div class="d-flex gap-1">
<button onclick="navigator.clipboard.writeText(document.getElementById('l<?= $r['id'] ?>').value);alert('Link Copied!')" class="btn-blue btn-sm">📋 Copy</button>
<a href="<?= $link ?>" target="_blank" class="btn-blue btn-sm text-decoration-none">👁️ View</a>
<a href="https://wa.me/?text=<?= urlencode('Your Certificate: '.$link) ?>" target="_blank" class="btn btn-success btn-sm">WhatsApp</a>
</div></td>
<td><a href="delete_certificate.php?id=<?= $r['id'] ?>" onclick="return confirm('Delete pannava?')" class="btn btn-danger btn-sm">Delete</a></td>
</tr>
<?php endwhile; ?>
</tbody></table>
</div>
<?php if($all->num_rows==0) echo "<p class='text-center text-muted py-4'>Innum Certificate illa. <b>Add Certificate</b> click pannu.</p>"; ?>
</div>
<div class="text-center py-3 small text-muted">© 2026 Next Level Academy • Admin Panel</div>
</div></body></html>