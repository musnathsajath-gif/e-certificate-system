
<?php
http_response_code(403);
exit('This installer has been disabled.');
