<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$error = ''; $success = ''; $name = ''; $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string)($_POST['name'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');
    if ($name === '' || $email === '' || $password === '') {
        $error = 'Please fill all required fields.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            if ($stmt->fetch()) { $error = 'This email is already registered. Please login.'; }
            else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO admins (name, email, password_hash, created_at) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$name, $email, $hash]);
                $success = 'Account created successfully! You can now login.';
                $name = ''; $email = '';
            }
        } catch (Throwable $e) { error_log('Admin register failed: ' . $e->getMessage()); $error = 'Unable to create account right now. Please try again later.'; }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create Account | Next Level Academy</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,700;0,800;1,600&display=swap" rel="stylesheet">
<style>
  *{font-family:'Inter',sans-serif}
  body{ background:#FFFEFA; min-height:100vh; display:flex; flex-direction:column; background:radial-gradient(ellipse at top, #FFF9E6 0%, #FFFEFA 60%); }
  .topbar{ background:linear-gradient(90deg,#0A2540,#123A63,#0A2540); color:#FFE9A8; font-size:12px; letter-spacing:2px; text-transform:uppercase; padding:10px 0; text-align:center; font-weight:600; }
  .topbar b{ color:#fff; }
  .navbar-elegant{ background:#fff; border-bottom:2px solid #F5E6B8; padding:14px 0; box-shadow:0 4px 20px rgba(0,0,0,.06); }
  .brand{ display:flex; align-items:center; gap:14px; text-decoration:none; }
  .brand-logo{ height:56px; width:auto; max-width:230px; object-fit:contain; display:block; }
  .brand-text{ line-height:1.15; }
  .brand-text .brand-main{ font-family:'Playfair Display',serif; font-size:26px; color:#0A2540; display:block; font-weight:800; letter-spacing:-.3px; }
  .brand-text .brand-sub{ font-size:10px; letter-spacing:3px; color:#C9A227; font-weight:800; text-transform:uppercase; }
  .back-link{ color:#0A2540; text-decoration:none; font-size:13px; font-weight:600; border:1px solid #E8D9A8; padding:9px 16px; border-radius:100px; background:#FFF9E6; }
  .back-link:hover{ background:#0A2540; color:#fff; }
  .main{ flex:1; display:flex; align-items:center; justify-content:center; padding:40px 15px; }
  .login-wrap{ width:100%; max-width:500px; }
  .login-card{ background:#fff; border:1px solid #F5E6B8; border-radius:24px; box-shadow:0 30px 60px rgba(10,37,64,.14); overflow:hidden; padding:36px 34px; }
  .eyebrow{ text-align:center; color:#B8962E; font-size:10.5px; letter-spacing:3.5px; font-weight:800; text-transform:uppercase; }
  .login-title{ font-family:'Playfair Display',serif; font-size:36px; color:#0A2540; text-align:center; margin:10px 0 6px; font-weight:800; }
  .login-title em{ background:linear-gradient(90deg,#C9A227,#F5D67B); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
  .login-sub{ text-align:center; color:#888; font-size:13.5px; margin-bottom:24px; }
  .gold-line{ width:56px; height:3px; background:linear-gradient(90deg,#C9A227,#F5D67B); margin:0 auto 26px; border-radius:10px; }
  .form-label{ font-size:11.5px; letter-spacing:.6px; text-transform:uppercase; font-weight:800; color:#222; margin-bottom:9px; }
  .form-control{ height:56px; border:2px solid #F0E6C5; border-radius:14px; font-size:14.5px; padding:0 16px; background:#FFFEFA; }
  .form-control:focus{ border-color:#C9A227; box-shadow:0 0 0 4px rgba(201,162,39,.18); background:#fff; }
  .btn-elegant{ width:100%; height:56px; background:linear-gradient(90deg,#0A2540,#123A63); color:#fff; border:none; border-radius:100px; font-size:13.5px; letter-spacing:1.2px; font-weight:800; text-transform:uppercase; box-shadow:0 12px 25px rgba(10,37,64,.25); transition:.3s; }
  .btn-elegant:hover{ background:linear-gradient(90deg,#C9A227,#E5C76B); color:#0A2540; transform:translateY(-2px); }
  .links{ text-align:center; margin-top:20px; font-size:13px; color:#777; line-height:2; }
  .links a{ color:#0A2540; font-weight:700; text-decoration:none; }
  .links a:hover{ color:#C9A227; }
  .secure-note{ display:flex; align-items:center; justify-content:center; gap:8px; margin-top:18px; background:#FFF9E6; border:1px solid #F5E6B8; padding:11px; border-radius:12px; font-size:12px; color:#6B5A35; font-weight:500; }
  .footer-elegant{ background:#0A2540; color:#8A9AAE; text-align:center; padding:20px 15px; font-size:12px; }
  .footer-elegant b{ color:#FFE9A8; }
  @media(max-width:576px){ .brand-text .brand-main{ font-size:19px; } .brand-logo{ height:42px; max-width:150px; } }
</style>
</head>
<body>
<div class="topbar">✦ &nbsp; <b>ADMINISTRATOR ACCESS</b> &nbsp; • &nbsp; NEXT LEVEL ACADEMY &nbsp; • &nbsp; SECURE REGISTRATION</div>
<nav class="navbar-elegant"><div class="container d-flex justify-content-between align-items-center">
  <a href="../index.php" class="brand">
    <img src="../images/dddf.jpg?v=3" alt="Next Level Academy" class="brand-logo">
    <span class="brand-text"><span class="brand-main">Certificate Verification</span><span class="brand-sub">Admin Portal • Official</span></span>
  </a>
  <a href="../index.php" class="back-link">← Back to Public Portal</a>
</div></nav>
<main class="main"><div class="login-wrap">
  <div class="login-card">
    <div class="eyebrow">Create Admin Account</div>
    <h1 class="login-title">Create <em>Account</em></h1>
    <p class="login-sub">Register to manage certificates for your institution.</p>
    <div class="gold-line"></div>
    <?php if ($error): ?><div class="alert alert-danger text-center" style="border-radius:12px;font-size:13.5px;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success text-center" style="border-radius:12px;font-size:13.5px;"><?= htmlspecialchars($success) ?> <a href="login.php">Login now →</a></div><?php endif; ?>
    <form method="post" action="register.php">
      <div class="mb-4"><label class="form-label">Full Name</label><input type="text" name="name" class="form-control" placeholder="Enter your full name" required value="<?= htmlspecialchars($name) ?>"></div>
      <div class="mb-4"><label class="form-label">Email Address</label><input type="email" name="email" class="form-control" placeholder="admin@nextlevel.lk" required value="<?= htmlspecialchars($email) ?>"></div>
      <div class="mb-4"><label class="form-label">Password</label><input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required></div>
      <div class="mb-4"><label class="form-label">Confirm Password</label><input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required></div>
      <button type="submit" class="btn-elegant">Create Account →</button>
    </form>
    <div class="links">Already have an account? <a href="login.php">Sign in</a><br><a href="../index.php">← Public Portal</a></div>
    <div class="secure-note">🔒 &nbsp; Secured Admin Area • Only authorized staff can access</div>
  </div>
</div></main>
<footer class="footer-elegant">© <?= date('Y') ?> <b>Next Level Academy</b> &nbsp;•&nbsp; ADMIN PORTAL &nbsp;•&nbsp; ALL RIGHTS RESERVED</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body></html>