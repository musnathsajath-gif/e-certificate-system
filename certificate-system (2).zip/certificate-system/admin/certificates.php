
<?php

$page_title = 'Manage Certificates';

require_once __DIR__ . '/../includes/admin_header.php';

$adminId = (int) $_SESSION['admin_id'];

$q = trim((string)($_GET['q'] ?? ''));
$status = (string)($_GET['status'] ?? '');

$message = '';
$error = '';

// Handle certificate actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $id = (int)($_POST['id'] ?? 0);
    $action = (string)($_POST['action'] ?? '');

    if ($id <= 0) {
        $error = 'Invalid certificate record.';
    } else {
        try {
            if ($action === 'delete') {

                $stmt = $pdo->prepare(
                    'DELETE FROM certificates
                     WHERE id = ? AND owner_admin_id = ?'
                );

                $stmt->execute([$id, $adminId]);

                $message = $stmt->rowCount()
                    ? 'Certificate deleted successfully.'
                    : 'Certificate record not found.';

            } elseif ($action === 'revoke') {

                $stmt = $pdo->prepare(
                    "UPDATE certificates
                     SET status = 'Revoked'
                     WHERE id = ? AND owner_admin_id = ?"
                );

                $stmt->execute([$id, $adminId]);

                $message = $stmt->rowCount()
                    ? 'Certificate revoked successfully.'
                    : 'Certificate record not found or already revoked.';

            } elseif ($action === 'restore') {

                $stmt = $pdo->prepare(
                    "UPDATE certificates
                     SET status = 'Valid'
                     WHERE id = ? AND owner_admin_id = ?"
                );

                $stmt->execute([$id, $adminId]);

                $message = $stmt->rowCount()
                    ? 'Certificate restored successfully.'
                    : 'Certificate record not found or already valid.';

            } else {
                $error = 'Invalid action.';
            }

        } catch (Throwable $e) {
            error_log('Certificate action failed: ' . $e->getMessage());
            $error = 'Could not complete the action. Please try again.';
        }
    }
}

// Fetch this admin's certificate records
$sql = 'SELECT id, tracking_number, student_name, student_email,
               course_name, issue_date, status
        FROM certificates
        WHERE owner_admin_id = ?';

$params = [$adminId];

if ($q !== '') {
    $sql .= ' AND (
        tracking_number LIKE ?
        OR student_name LIKE ?
        OR course_name LIKE ?
        OR student_email LIKE ?
    )';

    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}

if (in_array($status, ['Valid', 'Revoked'], true)) {
    $sql .= ' AND status = ?';
    $params[] = $status;
}

$sql .= ' ORDER BY id DESC LIMIT 250';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$rows = $stmt->fetchAll();

?>

<!-- Bootstrap CSS -->
<link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
>

<style>
.certificate-page {
    padding: 28px 0 50px;
}

.certificate-page .page-heading {
    font-size: 30px;
    font-weight: 750;
    color: #17243b;
    letter-spacing: -0.7px;
}

.certificate-page .page-subtitle {
    color: #718096;
    font-size: 14px;
}

.certificate-page .eyebrow {
    color: #dc2626;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 2px;
    margin-bottom: 8px;
}

.certificate-page .add-btn {
    background: #dc2626;
    color: white;
    border: none;
    border-radius: 9px;
    padding: 12px 20px;
    font-weight: 650;
    text-decoration: none;
    display: inline-block;
}

.certificate-page .add-btn:hover {
    background: #b91c1c;
    color: white;
}

.certificate-page .stats-card {
    border: 1px solid #e8edf4;
    border-radius: 13px;
    background: #fff;
    padding: 20px;
    height: 100%;
}

.certificate-page .stats-label {
    color: #718096;
    font-size: 13px;
    font-weight: 600;
}

.certificate-page .stats-number {
    font-size: 27px;
    font-weight: 750;
    color: #17243b;
    margin-top: 7px;
}

.certificate-page .content-card {
    background: #fff;
    border: 1px solid #e7ebf2;
    border-radius: 14px;
    box-shadow: 0 5px 22px rgba(20, 35, 60, 0.045);
    overflow: hidden;
}

.certificate-page .search-input,
.certificate-page .filter-select {
    min-height: 46px;
    border: 1px solid #dce3ed;
    border-radius: 8px;
}

.certificate-page .search-input:focus,
.certificate-page .filter-select:focus {
    border-color: #dc2626;
    box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.09);
}

.certificate-page .search-btn {
    background: #dc2626;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 11px 22px;
    font-weight: 650;
}

.certificate-page .search-btn:hover {
    background: #b91c1c;
}

.certificate-page .reset-btn {
    border: 1px solid #dce3ed;
    color: #526178;
    border-radius: 8px;
    padding: 11px 18px;
    text-decoration: none;
    font-weight: 600;
}

.certificate-page .reset-btn:hover {
    background: #f5f7fa;
}

.certificate-page .table {
    margin-bottom: 0;
    vertical-align: middle;
}

.certificate-page .table thead th {
    background: #f5f7fb;
    color: #65738a;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .5px;
    text-transform: uppercase;
    padding: 16px 14px;
    border-bottom: 1px solid #e5eaf1;
    white-space: nowrap;
}

.certificate-page .table tbody td {
    padding: 16px 14px;
    color: #354258;
    font-size: 13px;
    border-bottom: 1px solid #edf0f5;
}

.certificate-page .table tbody tr:hover {
    background: #fafbfe;
}

.certificate-page .tracking {
    font-weight: 750;
    color: #1e3558;
    white-space: nowrap;
}

.certificate-page .student-name {
    font-weight: 650;
    color: #26354d;
}

.certificate-page .status-badge {
    display: inline-block;
    border-radius: 30px;
    padding: 6px 12px;
    font-size: 11px;
    font-weight: 750;
}

.certificate-page .status-valid {
    color: #15803d;
    background: #dcfce7;
}

.certificate-page .status-revoked {
    color: #b91c1c;
    background: #fee2e2;
}

.certificate-page .action-btn {
    display: inline-block;
    padding: 7px 11px;
    border-radius: 7px;
    font-size: 12px;
    font-weight: 650;
    text-decoration: none;
    border: 1px solid transparent;
    cursor: pointer;
}

.certificate-page .edit-btn {
    color: #2563eb;
    background: #eff6ff;
    border-color: #dbeafe;
}

.certificate-page .revoke-btn {
    color: #b45309;
    background: #fffbeb;
    border-color: #fde68a;
}

.certificate-page .restore-btn {
    color: #15803d;
    background: #f0fdf4;
    border-color: #bbf7d0;
}

.certificate-page .delete-btn {
    color: #dc2626;
    background: #fff;
    border-color: #fecaca;
}

.certificate-page .action-btn:hover {
    filter: brightness(.96);
}

.certificate-page .public-link {
    color: #2563eb;
    font-weight: 650;
    text-decoration: none;
}

.certificate-page .public-link:hover {
    text-decoration: underline;
}

.certificate-page .record-footer {
    padding: 17px 20px;
    color: #718096;
    font-size: 12px;
    background: #fff;
}

.certificate-page .alert {
    border-radius: 9px;
    font-size: 14px;
}

.certificate-page .empty-state {
    padding: 45px 15px !important;
    text-align: center;
    color: #718096 !important;
}

@media (max-width: 767px) {
    .certificate-page {
        padding: 18px 0 35px;
    }

    .certificate-page .page-heading {
        font-size: 25px;
    }

    .certificate-page .header-actions {
        margin-top: 16px;
    }

    .certificate-page .search-btn,
    .certificate-page .reset-btn {
        width: 100%;
        text-align: center;
    }
}
</style>

<div class="container-fluid certificate-page">

    <!-- Page Heading -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">

        <div>
            <div class="eyebrow">CERTIFICATE MANAGEMENT</div>

            <h1 class="page-heading mb-2">
                Certificate Records
            </h1>

            <p class="page-subtitle mb-0">
                Manage, monitor and verify your issued certificates.
            </p>
        </div>

        <div class="header-actions">
            <a href="add-certificate.php" class="add-btn">
                + Add Certificate
            </a>
        </div>

    </div>

    <!-- Alerts -->
    <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <strong>Success!</strong>
            <?= h($message) ?>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
            <strong>Error!</strong>
            <?= h($error) ?>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <!-- Summary Cards -->
    <?php
    $totalCount = count($rows);
    $validCount = 0;
    $revokedCount = 0;

    foreach ($rows as $record) {
        if ($record['status'] === 'Valid') {
            $validCount++;
        } elseif ($record['status'] === 'Revoked') {
            $revokedCount++;
        }
    }
    ?>

    <div class="row g-3 mb-4">

        <div class="col-12 col-md-4">
            <div class="stats-card">
                <div class="stats-label">Records Shown</div>
                <div class="stats-number">
                    <?= $totalCount ?>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="stats-card">
                <div class="stats-label">Valid Certificates</div>
                <div class="stats-number text-success">
                    <?= $validCount ?>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-4">
            <div class="stats-card">
                <div class="stats-label">Revoked Certificates</div>
                <div class="stats-number text-danger">
                    <?= $revokedCount ?>
                </div>
            </div>
        </div>

    </div>

    <!-- Main Content -->
    <div class="content-card">

        <!-- Search and Filter -->
        <div class="p-3 p-md-4 border-bottom">

            <form method="get" class="row g-2 align-items-center">

                <div class="col-12 col-lg-6">
                    <input
                        type="search"
                        name="q"
                        class="form-control search-input"
                        placeholder="Search tracking number, student, course or email..."
                        value="<?= h($q) ?>"
                    >
                </div>

                <div class="col-12 col-md-5 col-lg-3">
                    <select name="status" class="form-select filter-select">
                        <option value="">All statuses</option>

                        <option value="Valid"
                            <?= $status === 'Valid' ? 'selected' : '' ?>>
                            Valid
                        </option>

                        <option value="Revoked"
                            <?= $status === 'Revoked' ? 'selected' : '' ?>>
                            Revoked
                        </option>
                    </select>
                </div>

                <div class="col-6 col-md-3 col-lg-2">
                    <button type="submit" class="search-btn w-100">
                        Search
                    </button>
                </div>

                <div class="col-6 col-md-4 col-lg-1">
                    <a href="certificates.php" class="reset-btn d-block text-center">
                        Reset
                    </a>
                </div>

            </form>

        </div>

        <!-- Certificate Table -->
        <div class="table-responsive">

            <table class="table">

                <thead>
                    <tr>
                        <th>Tracking Number</th>
                        <th>Student</th>
                        <th>Email</th>
                        <th>Course</th>
                        <th>Issue Date</th>
                        <th>Status</th>
                        <th>Public Page</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach ($rows as $r): ?>

                    <tr>

                        <td>
                            <span class="tracking">
                                <?= h($r['tracking_number']) ?>
                            </span>
                        </td>

                        <td>
                            <span class="student-name">
                                <?= h($r['student_name']) ?>
                            </span>
                        </td>

                        <td>
                            <?= h($r['student_email'] ?? '') ?>
                        </td>

                        <td>
                            <?= h($r['course_name']) ?>
                        </td>

                        <td class="text-nowrap">
                            <?= h($r['issue_date']) ?>
                        </td>

                        <td>
                            <?php if ($r['status'] === 'Valid'): ?>

                                <span class="status-badge status-valid">
                                    Valid
                                </span>

                            <?php else: ?>

                                <span class="status-badge status-revoked">
                                    Revoked
                                </span>

                            <?php endif; ?>
                        </td>

                        <td>
                            <a
                                href="../verify.php?id=<?= rawurlencode($r['tracking_number']) ?>"
                                target="_blank"
                                rel="noopener"
                                class="public-link"
                            >
                                Open ↗
                            </a>
                        </td>

                        <td class="text-nowrap">

                            <a
                                href="edit-certificate.php?id=<?= (int)$r['id'] ?>"
                                class="action-btn edit-btn"
                            >
                                Edit
                            </a>

                            <form method="post"
                                  class="d-inline"
                                  onsubmit="return confirm('Are you sure you want to continue?');">

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= h(csrf_token()) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= (int)$r['id'] ?>"
                                >

                                <?php if ($r['status'] === 'Valid'): ?>

                                    <button
                                        type="submit"
                                        name="action"
                                        value="revoke"
                                        class="action-btn revoke-btn"
                                        onclick="return confirm('Are you sure you want to revoke this certificate?');"
                                    >
                                        Revoke
                                    </button>

                                <?php else: ?>

                                    <button
                                        type="submit"
                                        name="action"
                                        value="restore"
                                        class="action-btn restore-btn"
                                        onclick="return confirm('Restore this certificate as Valid?');"
                                    >
                                        Restore
                                    </button>

                                <?php endif; ?>

                                <button
                                    type="submit"
                                    name="action"
                                    value="delete"
                                    class="action-btn delete-btn"
                                    onclick="return confirm('Permanently delete this certificate record? This cannot be undone.');"
                                >
                                    Delete
                                </button>

                            </form>

                        </td>

                    </tr>

                <?php endforeach; ?>

                <?php if (!$rows): ?>

                    <tr>
                        <td colspan="8" class="empty-state">

                            <div class="mb-2">
                                <strong>No certificates found</strong>
                            </div>

                            <div>
                                Try another search or add a new certificate.
                            </div>

                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

        <!-- Footer -->
        <div class="record-footer">
            Showing <?= count($rows) ?> records.
            Maximum 250 records.
        </div>

    </div>

</div>

<!-- Bootstrap JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
