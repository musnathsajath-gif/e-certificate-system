
<?php
$page_title = 'Settings';

require_once __DIR__ . '/../includes/admin_header.php';

$adminId = (int) $_SESSION['admin_id'];

$settings = get_settings($pdo);
$error = '';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $name = trim((string)($_POST['institution_name'] ?? ''));
    $prefix = trim((string)($_POST['certificate_prefix'] ?? 'NS'));
    $year = (int)($_POST['numbering_year'] ?? date('Y'));
    $footer = trim((string)($_POST['footer_text'] ?? ''));

    if (
        $name === '' ||
        $prefix === '' ||
        !preg_match('/^[A-Za-z0-9_-]{1,20}$/', $prefix) ||
        $year < 2020 ||
        $year > 2100
    ) {
        $error = 'Enter a valid institution name, prefix (letters/numbers/-/_), and year.';
    } else {
        $stmt = $pdo->prepare(
            'UPDATE settings
             SET institution_name = ?,
                 certificate_prefix = ?,
                 numbering_year = ?,
                 footer_text = ?
             WHERE id = ? AND owner_admin_id = ?'
        );

        $stmt->execute([
            $name,
            $prefix,
            $year,
            $footer,
            $settings['id'],
            $adminId
        ]);

        $message = 'Settings saved.';

        $settings = get_settings($pdo);
    }
}
?>

<div class="pagehead">
    <div>
        <div class="eyebrow">CONFIGURATION</div>
        <h1>Institution Settings</h1>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert success"><?= h($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert error"><?= h($error) ?></div>
<?php endif; ?>

<section class="panel">

    <form method="post">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h(csrf_token()) ?>"
        >

        <div class="form-grid">

            <div class="full">
                <label>Institution name</label>
                <input
                    name="institution_name"
                    required
                    value="<?= h($settings['institution_name']) ?>"
                >
            </div>

            <div>
                <label>Certificate prefix</label>
                <input
                    name="certificate_prefix"
                    required
                    maxlength="20"
                    value="<?= h($settings['certificate_prefix']) ?>"
                >
            </div>

            <div>
                <label>Numbering year</label>
                <input
                    type="number"
                    name="numbering_year"
                    min="2020"
                    max="2100"
                    required
                    value="<?= (int)$settings['numbering_year'] ?>"
                >
            </div>

            <div class="full">
                <label>Footer text</label>
                <input
                    name="footer_text"
                    maxlength="500"
                    value="<?= h($settings['footer_text']) ?>"
                >
            </div>

        </div>

        <div class="form-actions">
            <button type="submit">Save Settings</button>
        </div>

    </form>

</section>

<?php require __DIR__ . '/../includes/admin_footer.php'; ?>
