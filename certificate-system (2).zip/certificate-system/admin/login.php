<?php
session_start();
include '../config.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $u=$_POST['username']; $p=$_POST['password'];
    $res=$conn->query("SELECT * FROM admins WHERE username='$u' AND password='$p'");
    if($res->num_rows>0){ $_SESSION['admin']=$u; header("Location: dashboard.php"); exit; }
    else $err="Username / Password thappu!";
}
?>
<!DOCTYPE html>
<html><head><title>Admin Login - Next Level Academy</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Poppins',sans-serif}
body{
  background:#0A1931;
  min-height:100vh;
  display:flex;align-items:center;
  /* Bright illa - Light-a oru pattern mattum */
  background-image:radial-gradient(rgba(255,255,255,.04) 1px, transparent 1px);
  background-size:22px 22px;
}
.login-card{
  background:#FFFFFF;
  border-radius:18px;
  overflow:hidden;
  box-shadow:0 20px 50px rgba(0,0,0,.45);
  border:1px solid rgba(255,255,255,.08);
  max-width:420px;
  margin:auto;
}
.logo-area{
  background:#0A1931;
  padding:28px 20px 22px;
  text-align:center;
}
.logo-area img{
  max-width:200px;
  background:#fff;
  padding:8px 16px;
  border-radius:10px;
}
.logo-area p{
  color:#8FA3B8;
  font-size:11px;
  letter-spacing:3px;
  margin:14px 0 0;
  font-weight:600;
}
.gold-line{height:3px;background:#C9A227}
.form-box{padding:28px 30px 24px}
.form-box h4{font-weight:700;color:#0A1931;font-size:21px}
.form-box p{color:#6B7A90;font-size:13px}
label{font-size:12px;font-weight:600;color:#0A1931;letter-spacing:.5px}
.form-control{
  border-radius:10px;
  padding:11px 14px;
  border:1.5px solid #E2E8F0;
  background:#F8FAFC;
  font-size:14px;
  color:#0A1931;
}
.form-control:focus{
  background:#fff;
  border-color:#1E5AA8;
  box-shadow:0 0 0 3px rgba(30,90,168,.12);
  outline:none;
}
/* LOGIN BUTTON - NORMAL BLUE, CLICK / HOVER GOLD */
.btn-login{
  background:#1E5AA8; /* BLUE */
  color:#fff;
  font-weight:700;
  border:none;
  border-radius:10px;
  padding:13px;
  letter-spacing:1px;
  font-size:14px;
  width:100%;
  transition:all .25s ease;
  cursor:pointer;
}
.btn-login:hover{
  background:#C9A227; /* HOVER - GOLD */
  color:#fff;
  transform:translateY(-1px);
  box-shadow:0 8px 20px rgba(201,162,39,.35);
}
.btn-login:active, .btn-login:focus{
  background:#C9A227 !important; /* CLICK PANNINA - GOLD */
  color:#fff !important;
  transform:scale(.98);
}
.footer-text{font-size:12px;color:#94A3B8}
.footer-text a{color:#1E5AA8;font-weight:600;text-decoration:none}
.footer-text a:hover{color:#C9A227}
</style></head>
<body>
<div class="container"><div class="row justify-content-center"><div class="col-md-5">
<div class="login-card">
  <div class="logo-area">
    <img src="../images/logo.png" onerror="this.src='../images/logo.jpg';this.onerror=null;this.src='../images/dddf.jpg'" alt="NEXT LEVEL ACADEMY">
    <p>CERTIFICATE VERIFICATION SYSTEM</p>
  </div>
  <div class="gold-line"></div>
  <div class="form-box">
    <h4 class="text-center">Welcome Back</h4>
    <p class="text-center mb-4">Admin Panel - Next Level Academy</p>
    <?php if(isset($err)) echo "<div class='alert alert-danger rounded-3 py-2 small'>$err</div>"; ?>
    <form method="POST">
      <label class="mb-1">USERNAME</label>
      <input type="text" name="username" class="form-control mb-3" value="admin" required>
      <label class="mb-1">PASSWORD</label>
      <input type="password" name="password" class="form-control mb-4" value="12345" required>
      <button type="submit" class="btn-login">LOGIN →</button>
    </form>
    <p class="text-center mt-4 footer-text">© 2026 Next Level Academy • All Rights Reserved<br><a href="../index.php">← Back to Verification Portal</a></p>
  </div>
</div>
</div></div></div>
</body></html>