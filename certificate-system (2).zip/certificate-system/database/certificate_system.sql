CREATE DATABASE IF NOT EXISTS certificate_system
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE certificate_system;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  institution_name VARCHAR(255) NOT NULL DEFAULT 'Your Online Academy',
  certificate_prefix VARCHAR(50) NOT NULL DEFAULT 'NS',
  numbering_year INT NOT NULL DEFAULT 2026,
  logo_path VARCHAR(255) DEFAULT NULL,
  footer_text VARCHAR(500) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS certificates (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tracking_number VARCHAR(60) NOT NULL UNIQUE,
  student_name VARCHAR(200) NOT NULL,
  student_email VARCHAR(200) DEFAULT NULL,
  student_phone VARCHAR(50) DEFAULT NULL,
  course_name VARCHAR(200) NOT NULL,
  course_duration VARCHAR(100) DEFAULT NULL,
  completion_date DATE DEFAULT NULL,
  issue_date DATE NOT NULL,
  certificate_image VARCHAR(255) NOT NULL,
  institution_name VARCHAR(255) DEFAULT NULL,
  authorized_signatory VARCHAR(200) DEFAULT NULL,
  status ENUM('Valid','Revoked') NOT NULL DEFAULT 'Valid',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_student_name (student_name),
  INDEX idx_course_name (course_name),
  INDEX idx_issue_date (issue_date)
) ENGINE=InnoDB;

INSERT INTO settings (institution_name, certificate_prefix, numbering_year)
SELECT 'Your Online Academy', 'NS', YEAR(CURDATE())
WHERE NOT EXISTS (SELECT 1 FROM settings);
