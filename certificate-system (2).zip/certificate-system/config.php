<?php
$conn = new mysqli("localhost", "root", "", "certificate_system");
if ($conn->connect_error) die("DB Error: " . $conn->connect_error);
?>