# Certificate Verification System (PHP + MySQL)

## Requirements
- PHP 8.2+ with PDO MySQL, Fileinfo
- MySQL 8 / MariaDB
- Apache (XAMPP locally; cPanel or Hostinger hPanel in production)

## Local setup (XAMPP)
1. Copy this folder into `C:\xampp\htdocs\certificate-system`.
2. Start Apache and MySQL in XAMPP.
3. Open `http://localhost/phpmyadmin`.
4. Import `database/certificate_system.sql` (it creates/selects the database).
5. Confirm `config/database.php` uses local defaults (`root`, empty password).
6. Open `http://localhost/certificate-system/`.

## Create the first admin safely
Create a temporary file `create-admin-once.php` in project root with:

```php
<?php
require_once __DIR__ . '/config/database.php';
$username = 'admin';
$password = 'CHANGE_TO_A_LONG_UNIQUE_PASSWORD';
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $pdo->prepare('INSERT INTO admins (username, password) VALUES (?, ?)');
$stmt->execute([$username, $hash]);
echo 'Admin created. DELETE THIS FILE NOW.';
```

Open it once in the browser, then immediately delete the file. Never keep an admin-creation script on production.

Admin login: `/admin/login.php`

## Uploading certificates
- Admin → Add Certificate.
- Upload only a JPG, PNG or WebP image (maximum 5 MB).
- Tracking ID is generated from prefix/year in Settings.
- Public verification: `verify.php?id=TRACKING-NUMBER`.

## Production deployment (cPanel / Hostinger hPanel)
1. Create a MySQL database and a separate MySQL user; grant only needed privileges.
2. Export local database from phpMyAdmin and import into hosting phpMyAdmin.
3. Upload project files to the chosen web root (usually `public_html` or a subfolder).
4. Configure DB environment variables if hosting supports them:
   - `DB_HOST`
   - `DB_NAME`
   - `DB_USER`
   - `DB_PASS`
   Or update `config/database.php` with hosting credentials (do not share or commit them).
5. Set PHP 8.2+ and enable PDO MySQL + Fileinfo.
6. Enable SSL/HTTPS and test public search, admin login, upload, edit/status, and verification.
7. Ensure `uploads/certificates` is writable by PHP (often 755; follow host guidance).
8. Remove any temporary setup scripts. Keep backups of SQL and certificate files.

## Important production security checklist
- Use a unique strong admin password and HTTPS.
- Keep config credentials private and restrict config/internal folders.
- Back up MySQL and uploaded images.
- Review hosting-specific `.htaccess` behavior; some directives may not be allowed on shared hosting.
- Add rate limiting/login throttling, admin password change, audit logging, and malware scanning before public production use.
- The starter does not yet implement delete, CSV bulk import, QR rendering, or full audit history.
